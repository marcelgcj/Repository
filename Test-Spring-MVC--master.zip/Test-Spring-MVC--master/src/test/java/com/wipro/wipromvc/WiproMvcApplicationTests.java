package com.wipro.wipromvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiproMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
