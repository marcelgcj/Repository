package com.wipro.wipromvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(WiproMvcApplication.class, args);
	}

}
